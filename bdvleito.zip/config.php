<?php
return [
    'token' => '6895885757:AAEy9HMJRkecbXLdL3_FvukDYlJRNuCFxV8',
    'chat_id' => '-4040069896'
];
?>